Assuming your lammps executable is lmp_serial, you can calculate the elastic constants with the SNAP potential with the following command. 

```bash
lmp_serial -in in.elastic
```

Note: Make sure the snap package is installed when installing LAMMPS.